/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Procesos;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Gonzalo
 */
public class Procesos {
    
    public static void main(String[] args){
        /*String q1 = "dir";
        ejecutarComando(q1);*/
    
        /*String q2 = "pause";
        ejecutaComandoyComprueba(q2, 3);*/
        
        /*String q3 = "pause";
        EjecutaComandoyEspera(q3, 3);*/
        
        /*String q4 = "dir";
        File f = new File("C:\\Users");
        ejecutaComandoDirectorio(q4, f1);*/
    }
    
    
    public void ejecutarComando(String... comando){
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(comando);
		
		try{
			Process proceso = pb.start();
			imprimirResultado(proceso.getInputStream());

			// Esperar a que 		
			int exitVal = proceso.waitFor();
			if(exitVal != 0){
				System.out.println("Error ejecutando el comando");
			}
		}catch(IOException | InterruptedException e){
			e.printStackTrace();
		}
	}


	public static void ejecutaComandoyComprueba(String[] args){
		ProcessBuilder pb = new ProcessBuilder(args);
		pb.inheritIO();
		int tiempoEspera = 5000;

		try{
			Process proceso = pb.start();

			while(proceso.isAlive()){
				System.out.println("Esperando...");

				Thread.sleep(tiempoEspera);
			}
		}catch(InterruptedException in){
			System.out.println("Interrupted Exception error" + in);
		}catch(IOException i){
			System.out.println("IOException error" + i);
		}
	}

	/*public static void ejecutaComandoEspera(String comando, String[] argumentos) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(comando, argumentos);
            Process process = processBuilder.start();
            if (process.waitFor(5, java.util.concurrent.TimeUnit.SECONDS)) {
                System.out.println("Comando ejecutado exitosamente.");
            } else {
                process.destroy();
                System.err.println("El proceso no pudo completarse en 5 segundos.");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }*/
	
	public static void ejecutaComandoyEspera(String command, String arg1, String arg2){
		ArrayList<String> listaElem = new ArrayList<>();
		listaElem.add(command);
		listaElem.add(arg1);
		listaElem.add(arg2);
		
		ProcessBuilder pb3 = new ProcessBuilder(listaElem);
		pb3.inheritIO();
		System.out.println(listaElem);
		
		try{
			Process p = pb3.start();
			p.waitFor(5, TimeUnit.SECONDS);
			p.destroy();
		}catch(IOException | InterruptedException e){
			System.out.println("Error al realizar el proceso" + e);
		}
	}
	
	public static void ejecutaComandoDirectorio(File d, String comando){
		ProcessBuilder p = new ProcessBuilder("cmd.exe","/c", comando);
		if(d.exists()){
                    if(d.isDirectory()){
                        p.directory(d);
                    }else{
                        System.out.println("El archivo no es un directorio");
                        System.exit(1);
                    }
                }else{
                    System.out.println("No se ha indicado ningun directorio");
                    System.exit(1);
                }
                
                try{
                    p.inheritIO();
                    Process pc = p.start();
                    int codRet = pc.waitFor();
                    System.out.println(String.format("El proceso retorno %d", codRet));
                      
                    }catch(IOException | InterruptedException e){
                        System.out.println("Error al realizar el proceso "+e);
                    }
	}
	
	public static void buscayGuarda(String[] args){
		// comando: java .\App.java 5 powershell.exe Select-String -Path 'C:\Users\gonza\Escritorio\hola.txt' -Pattern 'hola' 'C:\Users\gonza\Escritorio\adios.txt'
                File archivoSalida = new File(args[args.length - 1]);
                String[] arrayComandos = Arrays.copyOfRange(args, 0, (args.length - 1));
                ProcessBuilder pb = new ProcessBuilder(arrayComandos);
                pb.redirectOutput(ProcessBuilder.Redirect.to(archivoSalida));
                int estadoProceso;
                
                try{
                    Process proceso = pb.start();
                    estadoProceso = proceso.waitFor();
                    
                    if(estadoProceso == 0){
                        System.out.println("El proceso se ha ejecutado con exito");
                        
                    }else{
                        System.out.println("Hubo un error con el proceso");
                    }
                }catch(InterruptedException in){
                    System.err.println("InterruptedException error "+in);
                    
                }catch(IOException i){
                    System.err.println("IOException error"+ i);
                }
        }

    private void imprimirResultado(InputStream inputStream) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
